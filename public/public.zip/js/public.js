var csrf = $('meta[name="csrf-token"]').attr('content');
$(document).ready(function () {
    checkScroll();
    $(window).scroll(checkScroll);
    /*
     * Check for active categories
     */
    var objCategories = $('.products-page .categories ul.children li');
    if (objCategories.length > 0) {
        objCategories.each(function () {
            if ($(this).hasClass('active')) {
                $(this).parents('ul').show();
                $(this).parent('ul').prev('span').find('.fa-minus').show();
                $(this).parent('ul').prev('span').find('.fa-plus').hide();
            } else {
                $(this).parent('ul').prev('span').find('.fa-minus').hide();
                $(this).parent('ul').prev('span').find('.fa-plus').show();
            }
        });
    }
});
$('.fast-order').toggle("slide", {direction: "right"}, 1000);
$('.fast-order .submit').click(function () {
    $('.fast-order .error').hide();
    var phone = $('#phone-user');
    var names = $('#names-user');
    var errors = false;
    if (!$.trim(phone.val())) {
        phone.next('.error').show();
        errors = true;
    }
    if (!$.trim(names.val())) {
        names.next('.error').show();
        errors = true;
    }
    if (errors == false) {
        document.getElementById("go-fast-order").submit();
    }
});
$('.fast-order .close').click(function () {
    if (xsMode()) {
        $('.fast-order-btn').show().addClass('visible-xs');
    }
    $('.fast-order').fadeOut('slow');
});
$('.show-right-menu').click(function () {
    $('.right-menu').toggle("slide", {direction: "left"}, 500);
    $('.backdrop').show();
});
$('.close-xs-menu').click(function () {
    $('.right-menu').toggle("slide", {direction: "left"}, 500);
    $('.backdrop').hide();
});
$('.fast-order-btn').click(function () {
    $('.fast-order').removeClass('hidden-xs');
    $('.fast-order').show();
    $(this).hide().removeClass('visible-xs');
});
/*
 * Add product to cart
 */
$('.buy-now.to-cart').click(function () {
    var product_id = $(this).data('product-id');
    addProduct(product_id);
});
/*
 * Show cart products in fast view
 */
$('.cart-button').on('click mouseover', function () {
    $('.cart-products-fast-view').fadeIn(200);
});
/*
 * If mouse leave, hide products fast view
 */
$('.cart-fast-view-container').on('mouseleave', function () {
    $('.cart-products-fast-view').fadeOut(200);
});
/*
 * change radio button selection for 
 * checkout payment type
 */
$('.box-type').click(function () {
    var radio_val = $(this).data('radio-val');
    $('input:radio[name="payment_type"][value="' + radio_val + '"]').prop('checked', true);
    $(this).addClass('active');
});
/*
 * Show/Hide sub categories when click - or +
 */
$('.products-page .categories ul li span').click(function () {
    var span = $(this);
    span.next('.children').slideToggle('fast', function () {
        if ($(this).is(':visible')) {
            span.find('.fa-minus').show();
            span.find('.fa-plus').hide();
        } else {
            span.find('.fa-minus').hide();
            span.find('.fa-plus').show();
        }
    });

});
/*
 * Hide cart products in fast view
 */
function closeFastCartView() {
    $('.cart-products-fast-view').fadeOut(200);
}
function checkScroll() {
    if ($(this).scrollTop() > 80) {
        if (xsMode() === false) {
            $('.header .navbar-custom').addClass('navbar-fixed-top').removeClass('trans-hide');
            var menuHeight = $('.navbar-custom').height();
            $('.top-part').css('margin-bottom', menuHeight);
        }
    } else {
        $('.header .navbar-custom').removeClass('navbar-fixed-top').addClass('trans-hide');
        $('.top-part').css('margin-bottom', '0');
    }
}
/*
 * Must return true if we are on xs mode
 * Must return false if we are not in xs mode
 */
function xsMode() {
    if ($('.navbar-brand').is(":visible") === false) {
        return false;
    } else {
        return true;
    }
}
/*
 * Add product with ajax to cart
 */
function addProduct(id) {
    var quantity = 1;
    var el_qa = $('[name="quantity"]');
    if (el_qa.length) {
        quantity = el_qa.val();
    }
    $.ajax({
        type: 'POST',
        url: urls.addProduct,
        headers: {
            'X-CSRF-TOKEN': csrf
        },

        data: {id: id, quantity: quantity}
    }).done(function (data) {
        renderCartProducts();
        renderCheckoutCartProducts();
        showAlertMessage('success', messages.addProductMsg);
    });
}
/*
 * Render cart products
 */
function renderCartProducts() {
    $.ajax({
        type: 'POST',
        url: urls.getProducts,
        headers: {
            'X-CSRF-TOKEN': csrf
        }
    }).done(function (data) {
        var obj = JSON.parse(data);
        console.log('obj === ', obj)
        // $('.cart-fast-view-container').append(obj.html);
        $('header .user .cart-amount').empty().append(obj.num_price_products);
    });
}
/*
 * Render products for checkout page
 */
function renderCheckoutCartProducts() {
    var products_container = $('.products-for-checkout');
    var current_height = products_container.height();
    if (products_container.length) {
        products_container.height(current_height);
        products_container.empty();
        // check only if we are in that page :)
        $.ajax({
            type: 'POST',
            url: urls.getProductsForCheckoutPage,
            headers: {
                'X-CSRF-TOKEN': csrf
            }
        }).done(function (data) {
            products_container.empty().append(data).height('auto');
        });
    }
}
/*
 * Remove product quantity from cart
 */
function removeQuantity(id) {
    $.ajax({
        type: 'POST',
        url: urls.removeProductQuantity,
        headers: {
            'X-CSRF-TOKEN': csrf
        },
        data: {id: id}
    }).done(function (data) {
        renderCartProducts();
        renderCheckoutCartProducts();
    });
}
/*
 * Complete order from checkout page - submit btn
 */
function completeOrder() {
    $('#errors').empty().hide();
    var errors = [];
    var phone = $('[name="phone"]').val();
    var address = $('[name="address"]').val();
    if ($.trim(phone).length <= 0) {
        errors[0] = variables.phoneReq;
    }
    if ($.trim(address).length <= 0) {
        errors[1] = variables.addressReq;
    }
    if ($('[name="id[]"]').length <= 0) {
        errors[2] = variables.productsReq;
    }
    if (errors.length > 0) {

        $.each(errors, function (index, value) {
            if (typeof value !== "undefined") {
                $('#errors').append(value + '<br>');
            }
        });
        $('#errors').fadeIn(200);
        $('html, body').animate({
            scrollTop: $("#errors").offset().top - 100
        }, 500);
    } else {
        document.getElementById('set-order').submit();
    }
}
/*
 * Remove product from cart
 */
function removeProduct(id) {
    $.ajax({
        type: 'POST',
        url: urls.removeProduct,
        headers: {
            'X-CSRF-TOKEN': csrf
        },
        data: {id: id}
    }).done(function (data) {
        renderCartProducts();
        renderCheckoutCartProducts();
    });
}

/*
 * If we are on product preview page
 * Carusel for images
 */
if ($('.product-preview').length > 0) {
    $("#inner-slider").on('slide.bs.carousel', function (evt) {
        var thisSlideI = $(this).find('.active').index();
        var nextSlideI = $(evt.relatedTarget).index();
        $('[data-slide-to="' + thisSlideI + '"]').removeClass('active');
        $('[data-slide-to="' + nextSlideI + '"]').addClass('active');
    });
}


/**
 * return the selected product
 */
function returnProduct(id) {
    $.ajax({
        type: 'POST',
        url: urls.returnOrder,
        headers: {
            'X-CSRF-TOKEN': csrf
        },
        data: {
            order_id: id,
            order_value: 4,         // 4: request order returning
        }
    }).done(function (data) {
        $('#order_'+id+' .order-status').empty().append('Returning');
        showAlertMessage('success', messages.returnMsg);
    });
}

/**
 * leave a review per order 
 */
function leaveReviewProduct(id, message) {
    $.ajax({
        type: 'POST',
        url: urls.leaveReview,
        headers: {
            'X-CSRF-TOKEN': csrf
        },
        data: {
            order_id: id,
            msg: message,
        }
    }).done(function (data) {
        showAlertMessage('success', messages.leaveReviewMsg);
    });
}

/**
 * show alert message
 * @param {*} status: success: 'success', danger: 'danger' 
 * @param {*} msg 
 */
function showAlertMessage(status, msg) {
    $('body').append(' \
        <div class="alert alert-'+ status + ' alert-top" id="notification_message"> \
            '+msg+' \
        </div> \
    ');
    $('#notification_message').delay(5000).queue(function () {
        $(this).remove();
    });
}

////////////////// stripe payment. ////////////////////////
var stripe_public_key = keys.stripePublicKey;
var stripe = Stripe(stripe_public_key);
var elements = stripe.elements();

// Custom styling can be passed to options when creating an Element.
var style = {
    base: {
        // Add your base input styles here. For example:
        fontSize: '16px',
        color: '#32325d',
    },
};

// Create an instance of the card Element.
var card = elements.create('card', {style: style});

// Add an instance of the card Element into the `card-element` <div>.
card.mount('#card-element');

// Create a token or display an error when the form is submitted.
var form = document.getElementById('payment-form');

var evtSource = "";
function stripeClicked() {
    evtSource = "stripe";
    $("#submitBtn").click();
}

function paypalClicked() {
    evtSource = "paypal";
    $("#submitBtn").click();
}

form.addEventListener('submit', function(event) {

    if (evtSource == 'stripe') {
        event.preventDefault();
    
        stripe.createToken(card).then(function(result) {
            if (result.error) {
                // Inform the customer that there was an error.
                var errorElement = document.getElementById('card-errors');
                errorElement.textContent = result.error.message;
            } else {
                // Send the token to your server.
                stripeTokenHandler(result.token);
            }
        });
    } else if (evtSource == 'paypal') {
        payWithPayPal();
    }
});

function stripeTokenHandler(token) {
    // Insert the token ID into the form so it gets submitted to the server
    var form = document.getElementById('payment-form');
    var hiddenInput = document.createElement('input');
    hiddenInput.setAttribute('type', 'hidden');
    hiddenInput.setAttribute('name', 'stripeToken');
    hiddenInput.setAttribute('value', token.id);
    form.appendChild(hiddenInput);
    
    // Submit the form
    form.submit();
}
////////////////////////////////////////////////////

///////////////PayPal Payment///////////////////////
function payWithPayPal() {
    event.preventDefault();

    var billing_address = $('#payment-form').find('input[name="billing_address"]').val();
    var delivery_address = $('#payment-form').find('input[name="delivery_address"]').val();
    var payment_transfer_type = $('#payment-form').find('input[name="payment_transfer_type"]').val();

    var headUrl = urls.mainUrl;
    var url = '/customer/chargewithpaypal?billing_address='+billing_address+'&delivery_address='+delivery_address+'&payment_transfer_type='+payment_transfer_type;
    url = headUrl + url
    
    window.location.href = url;

}
/////////////////////////////////////////////////////

/**
 * save the transer type
 */
function saveTransferType() {
    var type = $('input[name="payment_transfer_type"]:checked').val();
    localStorage.setItem("payment_transfer_type", type);
}
