<?php

return [
    'title_home' => 'Home',
    'descr_home' => 'Food Supplements Shop',
    'title_products' => 'Products',
    'descr_products' => 'Products of proven quality',
    'title_contacts' => 'Contacts',
    'descr_contacts' => 'Write us message or call us',
    'title_checkout' => 'Checkout',
    'descr_checkout' => 'Online store with paypal support, bank payments and cash on delivery',
    'descr_products_category' => 'Supplements of category - ',

    /* new added */
    'title_register' => 'Register',
    'descr_register' => 'Register',
    'title_login' => 'Login',
    'desc_login' => 'Login'
];
